import { X } from 'lucide-react';
import { format } from 'date-fns';
import { Booking } from '../lib/supabase';

type BookingConfirmationProps = {
  booking: Booking;
  onClose: () => void;
};

const BookingConfirmation = ({ booking, onClose }: BookingConfirmationProps) => {
  const formattedDate = format(new Date(booking.booking_date), 'EEEE, MMMM d, yyyy');
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-lg shadow-xl max-w-md w-full animate-slide-up">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-amber-500">Booking Confirmed!</h2>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="bg-gray-700 p-4 rounded-lg mb-4">
            <p className="text-center text-lg mb-4">
              Thank you for booking with Rising Performance Hall!
            </p>
            
            <div className="space-y-3 text-gray-300">
              <div className="flex justify-between">
                <span className="font-medium">Booking ID:</span>
                <span className="text-right">{booking.id.slice(0, 8)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Event:</span>
                <span className="text-right">{booking.event_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Date:</span>
                <span className="text-right">{formattedDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Time:</span>
                <span className="text-right">{booking.start_time} - {booking.end_time}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Contact:</span>
                <span className="text-right">{booking.contact_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Status:</span>
                <span className="text-right bg-green-900 text-green-100 px-2 py-0.5 rounded-full text-xs">
                  Confirmed
                </span>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-4">
              A confirmation email has been sent to your registered email address.
            </p>
            <button
              onClick={onClose}
              className="bg-amber-500 text-gray-900 py-2 px-6 rounded-md font-medium hover:bg-amber-400 transition-colors"
            >
              OK
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmation;