import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';

type TimeSlotSelectorProps = {
  selectedDate: Date | null;
  onSelectTimeSlot: (startTime: string, endTime: string) => void;
};

type TimeSlot = {
  id: string;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
};

// Generate time slots from 9 AM to 9 PM with 1-hour increments
const generateTimeSlots = (): TimeSlot[] => {
  const slots: TimeSlot[] = [];
  const startHour = 9; // 9 AM
  const endHour = 21; // 9 PM
  
  for (let hour = startHour; hour < endHour; hour++) {
    const startTime = `${hour.toString().padStart(2, '0')}:00`;
    const endTime = `${(hour + 1).toString().padStart(2, '0')}:00`;
    
    slots.push({
      id: `${startTime}-${endTime}`,
      startTime,
      endTime,
      isAvailable: true,
    });
  }
  
  return slots;
};

const TimeSlotSelector = ({ selectedDate, onSelectTimeSlot }: TimeSlotSelectorProps) => {
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>(generateTimeSlots());
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    const fetchBookedTimeSlots = async () => {
      if (!selectedDate) return;
      
      setLoading(true);
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('bookings')
        .select('start_time, end_time')
        .eq('booking_date', dateStr)
        .eq('status', 'confirmed');
      
      if (error) {
        console.error('Error fetching booked time slots:', error);
      } else {
        // Reset all slots to available
        const updatedSlots = generateTimeSlots();
        
        // Mark booked slots as unavailable
        data.forEach(booking => {
          const slotId = `${booking.start_time}-${booking.end_time}`;
          const slotIndex = updatedSlots.findIndex(slot => slot.id === slotId);
          
          if (slotIndex !== -1) {
            updatedSlots[slotIndex].isAvailable = false;
          }
        });
        
        setTimeSlots(updatedSlots);
      }
      
      setLoading(false);
      setSelectedSlot(null); // Reset selection when date changes
    };
    
    fetchBookedTimeSlots();
  }, [selectedDate]);
  
  const handleSelectTimeSlot = (slot: TimeSlot) => {
    if (!slot.isAvailable) return;
    
    setSelectedSlot(slot.id);
    onSelectTimeSlot(slot.startTime, slot.endTime);
  };
  
  if (!selectedDate) {
    return (
      <div className="text-center p-4 bg-gray-800 rounded-lg">
        <p className="text-gray-400">Please select a date first</p>
      </div>
    );
  }
  
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gray-800 rounded-lg shadow p-4">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Clock size={18} className="mr-2 text-amber-500" />
          Select Time Slot
        </h3>
        
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-amber-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {timeSlots.map((slot) => (
              <button
                key={slot.id}
                onClick={() => handleSelectTimeSlot(slot)}
                disabled={!slot.isAvailable}
                className={`
                  p-3 rounded-md text-sm
                  ${selectedSlot === slot.id ? 'bg-amber-500 text-gray-900 font-medium' : ''}
                  ${!slot.isAvailable ? 'bg-red-900/30 text-gray-500 cursor-not-allowed' : ''}
                  ${slot.isAvailable && selectedSlot !== slot.id ? 'bg-gray-700 hover:bg-gray-600' : ''}
                  transition-colors
                `}
              >
                {slot.startTime} - {slot.endTime}
              </button>
            ))}
          </div>
        )}
        
        {timeSlots.every(slot => !slot.isAvailable) && !loading && (
          <p className="text-center mt-4 text-amber-500">
            All time slots are booked for this date. Please select another date.
          </p>
        )}
      </div>
    </div>
  );
};

export default TimeSlotSelector;