import { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';

type BookingCalendarProps = {
  onSelectDate: (date: Date) => void;
  selectedDate: Date | null;
};

const BookingCalendar = ({ onSelectDate, selectedDate }: BookingCalendarProps) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [bookedDates, setBookedDates] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Fetch booked dates from the database
  useEffect(() => {
    const fetchBookedDates = async () => {
      setLoading(true);
      
      const startDate = format(startOfMonth(currentMonth), 'yyyy-MM-dd');
      const endDate = format(endOfMonth(currentMonth), 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('bookings')
        .select('booking_date')
        .gte('booking_date', startDate)
        .lte('booking_date', endDate)
        .eq('status', 'confirmed');
      
      if (error) {
        console.error('Error fetching booked dates:', error);
      } else {
        // Extract unique dates
        const dates = data.map(booking => booking.booking_date);
        setBookedDates(dates);
      }
      
      setLoading(false);
    };
    
    fetchBookedDates();
  }, [currentMonth]);
  
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  
  // Generate days for the current month view
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  // Determine if a date is fully booked
  const isDateBooked = (date: Date) => {
    const dateString = format(date, 'yyyy-MM-dd');
    return bookedDates.includes(dateString);
  };
  
  // Determine if a date is in the past
  const isPastDate = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };
  
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gray-800 rounded-lg shadow p-4">
        {/* Calendar header */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={prevMonth}
            className="p-2 rounded-full hover:bg-gray-700 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-xl font-semibold flex items-center">
            <CalendarIcon size={20} className="mr-2 text-amber-500" />
            {format(currentMonth, 'MMMM yyyy')}
          </h2>
          <button
            onClick={nextMonth}
            className="p-2 rounded-full hover:bg-gray-700 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        
        {/* Weekday headers */}
        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
          {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
            <div key={day} className="text-sm font-medium text-gray-400 py-1">
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-1">
          {monthDays.map((day, i) => {
            const isBooked = isDateBooked(day);
            const isPast = isPastDate(day);
            const isSelected = selectedDate && isSameDay(day, selectedDate);
            
            return (
              <button
                key={i}
                onClick={() => !isPast && !isBooked && onSelectDate(day)}
                disabled={isPast || isBooked || loading}
                className={`
                  h-10 w-full rounded-md flex items-center justify-center relative
                  ${isSelected ? 'bg-amber-500 text-gray-900 font-medium' : ''}
                  ${isPast ? 'text-gray-600 cursor-not-allowed' : ''}
                  ${isBooked ? 'bg-red-900/30 text-gray-400 cursor-not-allowed' : ''}
                  ${!isPast && !isBooked && !isSelected ? 'hover:bg-gray-700' : ''}
                  transition-colors
                `}
              >
                <span>{format(day, 'd')}</span>
                
                {/* Booking indicator */}
                {isBooked && (
                  <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-red-500 rounded-full"></span>
                )}
              </button>
            );
          })}
        </div>
        
        {/* Legend */}
        <div className="mt-4 flex justify-between text-xs text-gray-400">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-900/30 rounded-full mr-1"></div>
            <span>Booked</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-amber-500 rounded-full mr-1"></div>
            <span>Selected</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-gray-600 rounded-full mr-1"></div>
            <span>Past</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingCalendar;