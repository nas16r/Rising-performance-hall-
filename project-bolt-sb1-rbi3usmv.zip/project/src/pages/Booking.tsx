import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Calendar, Clock, CalendarCheck } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { supabase, Booking as BookingType } from '../lib/supabase';
import BookingCalendar from '../components/BookingCalendar';
import TimeSlotSelector from '../components/TimeSlotSelector';
import BookingConfirmation from '../components/BookingConfirmation';

const Booking = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [startTime, setStartTime] = useState<string>('');
  const [endTime, setEndTime] = useState<string>('');
  const [eventName, setEventName] = useState('');
  const [contactNumber, setContactNumber] = useState(user?.phone || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmedBooking, setConfirmedBooking] = useState<BookingType | null>(null);
  
  const handleSelectDate = (date: Date) => {
    setSelectedDate(date);
  };
  
  const handleSelectTimeSlot = (start: string, end: string) => {
    setStartTime(start);
    setEndTime(end);
  };
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!eventName.trim()) {
      newErrors.eventName = 'Event name is required';
    }
    
    if (!contactNumber.trim()) {
      newErrors.contactNumber = 'Contact number is required';
    }
    
    if (!selectedDate) {
      newErrors.date = 'Please select a date';
    }
    
    if (!startTime || !endTime) {
      newErrors.time = 'Please select a time slot';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    if (!user) {
      navigate('/signin');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const bookingDate = format(selectedDate!, 'yyyy-MM-dd');
      
      // Create booking in database
      const { data, error } = await supabase
        .from('bookings')
        .insert([
          {
            user_id: user.id,
            event_name: eventName,
            contact_number: contactNumber,
            booking_date: bookingDate,
            start_time: startTime,
            end_time: endTime,
            status: 'confirmed',
          },
        ])
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      // Show confirmation
      setConfirmedBooking(data);
      
      // Reset form
      setEventName('');
      setSelectedDate(null);
      setStartTime('');
      setEndTime('');
    } catch (error) {
      console.error('Error creating booking:', error);
      setErrors({
        submit: 'There was a problem creating your booking. Please try again.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleCloseConfirmation = () => {
    setConfirmedBooking(null);
  };
  
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-amber-500 mb-4">Book Our Venue</h1>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Reserve the Rising Performance Hall for your next event. Please fill out the form below to make your booking.
        </p>
      </div>
      
      <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 md:p-8">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h2 className="text-xl font-semibold mb-6 flex items-center">
                  <CalendarCheck size={20} className="mr-2 text-amber-500" />
                  Event Details
                </h2>
                
                <div className="space-y-4 mb-8">
                  {/* Event Name */}
                  <div>
                    <label htmlFor="eventName" className="form-label">
                      Event Name
                    </label>
                    <input
                      type="text"
                      id="eventName"
                      value={eventName}
                      onChange={(e) => setEventName(e.target.value)}
                      className={`form-input ${errors.eventName ? 'border-red-500' : ''}`}
                      placeholder="Conference, Wedding, Concert, etc."
                    />
                    {errors.eventName && <p className="form-error">{errors.eventName}</p>}
                  </div>
                  
                  {/* Contact Number */}
                  <div>
                    <label htmlFor="contactNumber" className="form-label">
                      Contact Number
                    </label>
                    <input
                      type="tel"
                      id="contactNumber"
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      className={`form-input ${errors.contactNumber ? 'border-red-500' : ''}`}
                      placeholder="(123) 456-7890"
                    />
                    {errors.contactNumber && <p className="form-error">{errors.contactNumber}</p>}
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <Calendar size={18} className="mr-2 text-amber-500" />
                  Select Date
                </h3>
                
                <BookingCalendar 
                  onSelectDate={handleSelectDate} 
                  selectedDate={selectedDate}
                />
                {errors.date && <p className="form-error mt-2">{errors.date}</p>}
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <Clock size={18} className="mr-2 text-amber-500" />
                  Select Time Slot
                </h3>
                
                <TimeSlotSelector
                  selectedDate={selectedDate}
                  onSelectTimeSlot={handleSelectTimeSlot}
                />
                {errors.time && <p className="form-error mt-2">{errors.time}</p>}
                
                <div className="mt-8">
                  <h3 className="text-lg font-medium mb-4">Booking Summary</h3>
                  
                  <div className="bg-gray-700 rounded-lg p-4 mb-6">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Event:</span>
                        <span className="font-medium">{eventName || '—'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Date:</span>
                        <span className="font-medium">
                          {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : '—'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Time:</span>
                        <span className="font-medium">
                          {startTime && endTime ? `${startTime} - ${endTime}` : '—'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Contact:</span>
                        <span className="font-medium">{contactNumber || '—'}</span>
                      </div>
                    </div>
                  </div>
                  
                  {errors.submit && (
                    <div className="bg-red-900/50 border border-red-500 text-red-100 px-4 py-3 rounded mb-4">
                      {errors.submit}
                    </div>
                  )}
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full btn btn-primary py-3"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-gray-900\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                          <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processing...
                      </span>
                    ) : (
                      'Book Now'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      
      {confirmedBooking && (
        <BookingConfirmation 
          booking={confirmedBooking} 
          onClose={handleCloseConfirmation}
        />
      )}
    </div>
  );
};

export default Booking;