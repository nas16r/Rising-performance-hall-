import { Link } from 'react-router-dom';
import ImageCarousel from '../components/ImageCarousel';
import { useAuthStore } from '../store/authStore';

const Welcome = () => {
  const { user } = useAuthStore();
  
  // Sample stage images
  const stageImages = [
    {
      src: "https://images.pexels.com/photos/236705/pexels-photo-236705.jpeg?auto=compress&cs=tinysrgb&w=1600",
      alt: "Concert hall with stage and seating"
    },
    {
      src: "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1600",
      alt: "Theater stage with lighting"
    },
    {
      src: "https://images.pexels.com/photos/257904/pexels-photo-257904.jpeg?auto=compress&cs=tinysrgb&w=1600",
      alt: "Performance venue with stage"
    },
    {
      src: "https://images.pexels.com/photos/1708936/pexels-photo-1708936.jpeg?auto=compress&cs=tinysrgb&w=1600",
      alt: "Concert with spotlight"
    }
  ];

  return (
    <div className="relative min-h-[calc(100vh-64px)]">
      {/* Background image carousel */}
      <div className="absolute inset-0 h-full w-full">
        <ImageCarousel images={stageImages} interval={5000} />
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      </div>
      
      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center text-center px-4 py-16 sm:py-24">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 text-white">
            Welcome to <span className="text-amber-500">RISING PERFORMANCE HALL</span>
          </h1>
          
          <p className="text-xl sm:text-2xl mb-8 text-gray-200">
            Your premier venue for unforgettable performances and special events
          </p>
          
          <div className="animate-pulse-slow">
            <Link 
              to={user ? "/booking" : "/signup"} 
              className="btn btn-primary text-lg py-3 px-8"
            >
              {user ? "Book Now" : "Get Started"}
            </Link>
          </div>
          
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="bg-gray-900 bg-opacity-80 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-3 text-amber-500">Versatile Space</h2>
              <p className="text-gray-300">Perfect for concerts, theater productions, dance performances, corporate events and more.</p>
            </div>
            
            <div className="bg-gray-900 bg-opacity-80 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-3 text-amber-500">State-of-the-Art</h2>
              <p className="text-gray-300">Equipped with professional sound, lighting, and staging equipment for any performance needs.</p>
            </div>
            
            <div className="bg-gray-900 bg-opacity-80 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-3 text-amber-500">Seamless Booking</h2>
              <p className="text-gray-300">Our easy online booking system lets you secure your preferred dates instantly.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Welcome;