import { useState, useEffect } from 'react';
import { format, parseISO, isFuture } from 'date-fns';
import { Calendar, Clock, User, Calendar as CalendarIcon, X, CheckCircle, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { supabase, Booking } from '../lib/supabase';

const MyBookings = () => {
  const { user } = useAuthStore();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancelSuccess, setCancelSuccess] = useState(false);
  
  useEffect(() => {
    fetchBookings();
  }, []);
  
  const fetchBookings = async () => {
    if (!user) return;
    
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('user_id', user.id)
        .order('booking_date', { ascending: true });
      
      if (error) {
        throw error;
      }
      
      setBookings(data || []);
    } catch (err: any) {
      console.error('Error fetching bookings:', err);
      setError('Failed to load your bookings. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleCancelBooking = async (bookingId: string) => {
    setCancellingId(bookingId);
    setCancelSuccess(false);
    
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', bookingId);
      
      if (error) {
        throw error;
      }
      
      // Update the booking in local state
      setBookings(bookings.map(booking => 
        booking.id === bookingId 
          ? { ...booking, status: 'cancelled' as const } 
          : booking
      ));
      
      setCancelSuccess(true);
      
      // Reset after a delay
      setTimeout(() => {
        setCancelSuccess(false);
        setCancellingId(null);
      }, 2000);
    } catch (err) {
      console.error('Error cancelling booking:', err);
      setCancellingId(null);
    }
  };
  
  // Filter bookings based on active tab
  const filteredBookings = bookings.filter(booking => {
    const bookingDate = parseISO(`${booking.booking_date}T${booking.start_time}`);
    const isFutureBooking = isFuture(bookingDate);
    
    if (activeTab === 'upcoming') {
      return isFutureBooking && booking.status === 'confirmed';
    } else {
      return !isFutureBooking || booking.status === 'cancelled';
    }
  });
  
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-amber-500 mb-4">My Bookings</h1>
        <p className="text-gray-300 max-w-2xl mx-auto">
          View and manage all your bookings at Rising Performance Hall
        </p>
      </div>
      
      {/* Tabs */}
      <div className="flex border-b border-gray-700 mb-8">
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'upcoming'
              ? 'text-amber-500 border-b-2 border-amber-500'
              : 'text-gray-400 hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('upcoming')}
        >
          Upcoming Bookings
        </button>
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'past'
              ? 'text-amber-500 border-b-2 border-amber-500'
              : 'text-gray-400 hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('past')}
        >
          Past & Cancelled Bookings
        </button>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-900/50 border border-red-500 text-red-100 px-6 py-4 rounded-lg flex items-center">
          <AlertCircle size={24} className="mr-3" />
          <p>{error}</p>
        </div>
      ) : filteredBookings.length === 0 ? (
        <div className="text-center py-12 bg-gray-800 rounded-lg">
          <CalendarIcon size={48} className="mx-auto text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-300 mb-2">No {activeTab} bookings</h3>
          <p className="text-gray-400">
            {activeTab === 'upcoming' 
              ? "You don't have any upcoming bookings." 
              : "You don't have any past or cancelled bookings."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredBookings.map((booking) => {
            const bookingDate = parseISO(booking.booking_date);
            const formattedDate = format(bookingDate, 'EEEE, MMMM d, yyyy');
            const isPastOrCancelled = 
              !isFuture(parseISO(`${booking.booking_date}T${booking.start_time}`)) || 
              booking.status === 'cancelled';
            
            return (
              <div 
                key={booking.id} 
                className={`bg-gray-800 rounded-lg shadow-md overflow-hidden ${
                  booking.status === 'cancelled' ? 'border border-red-800/50' : ''
                }`}
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-semibold">{booking.event_name}</h3>
                    {booking.status === 'cancelled' ? (
                      <span className="px-2 py-1 bg-red-900/30 text-red-300 rounded-full text-xs">
                        Cancelled
                      </span>
                    ) : !isPastOrCancelled ? (
                      <span className="px-2 py-1 bg-green-900/30 text-green-300 rounded-full text-xs">
                        Confirmed
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-700 text-gray-400 rounded-full text-xs">
                        Completed
                      </span>
                    )}
                  </div>
                  
                  <div className="space-y-3 text-gray-300">
                    <div className="flex items-start">
                      <Calendar size={18} className="mr-2 text-amber-500 mt-0.5" />
                      <span>{formattedDate}</span>
                    </div>
                    <div className="flex items-start">
                      <Clock size={18} className="mr-2 text-amber-500 mt-0.5" />
                      <span>{booking.start_time} - {booking.end_time}</span>
                    </div>
                    <div className="flex items-start">
                      <User size={18} className="mr-2 text-amber-500 mt-0.5" />
                      <span>{booking.contact_number}</span>
                    </div>
                  </div>
                  
                  {!isPastOrCancelled && booking.status !== 'cancelled' && (
                    <div className="mt-6">
                      <button
                        onClick={() => handleCancelBooking(booking.id)}
                        disabled={cancellingId === booking.id}
                        className={`flex items-center justify-center w-full py-2 rounded-md
                          ${cancellingId === booking.id && !cancelSuccess
                            ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                            : cancellingId === booking.id && cancelSuccess
                            ? 'bg-green-600 text-white'
                            : 'bg-red-600 text-white hover:bg-red-500'
                          }
                          transition-colors
                        `}
                      >
                        {cancellingId === booking.id ? (
                          cancelSuccess ? (
                            <>
                              <CheckCircle size={18} className="mr-2" />
                              Cancelled
                            </>
                          ) : (
                            <>
                              <svg className="animate-spin h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Cancelling...
                            </>
                          )
                        ) : (
                          <>
                            <X size={18} className="mr-2" />
                            Cancel Booking
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MyBookings;