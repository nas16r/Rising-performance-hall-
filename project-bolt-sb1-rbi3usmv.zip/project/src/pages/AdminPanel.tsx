import { useState, useEffect } from 'react';
import { format, parseISO, isFuture } from 'date-fns';
import { Calendar, Clock, User, Search, Filter, Check, X, Phone } from 'lucide-react';
import { supabase, Booking } from '../lib/supabase';

type BookingWithUser = Booking & {
  profiles: {
    name: string;
    email: string;
  };
};

const AdminPanel = () => {
  const [bookings, setBookings] = useState<BookingWithUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'all'>('upcoming');
  const [searchTerm, setSearchTerm] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState(false);
  
  useEffect(() => {
    fetchBookings();
  }, [activeTab]);
  
  const fetchBookings = async () => {
    setLoading(true);
    setError('');
    
    try {
      let query = supabase
        .from('bookings')
        .select(`
          *,
          profiles:user_id (
            name,
            email
          )
        `)
        .order('booking_date', { ascending: true });
      
      const { data, error } = await query;
      
      if (error) {
        throw error;
      }
      
      setBookings(data as BookingWithUser[]);
    } catch (err: any) {
      console.error('Error fetching bookings:', err);
      setError('Failed to load bookings. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleActionBooking = async (bookingId: string, action: 'confirm' | 'cancel') => {
    setProcessingId(bookingId);
    setActionSuccess(false);
    
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: action === 'confirm' ? 'confirmed' : 'cancelled' })
        .eq('id', bookingId);
      
      if (error) {
        throw error;
      }
      
      // Update the booking in local state
      setBookings(bookings.map(booking => 
        booking.id === bookingId 
          ? { ...booking, status: action === 'confirm' ? 'confirmed' as const : 'cancelled' as const } 
          : booking
      ));
      
      setActionSuccess(true);
      
      // Reset after a delay
      setTimeout(() => {
        setActionSuccess(false);
        setProcessingId(null);
      }, 2000);
    } catch (err) {
      console.error(`Error ${action}ing booking:`, err);
      setProcessingId(null);
    }
  };
  
  // Filter bookings based on active tab and search term
  const filteredBookings = bookings.filter(booking => {
    const bookingDate = parseISO(`${booking.booking_date}T${booking.start_time}`);
    const isFutureBooking = isFuture(bookingDate);
    
    // First filter by tab
    let matchesTab = true;
    if (activeTab === 'upcoming') {
      matchesTab = isFutureBooking;
    } else if (activeTab === 'past') {
      matchesTab = !isFutureBooking;
    }
    
    // Then filter by search term if provided
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase();
      return (
        matchesTab &&
        (booking.event_name.toLowerCase().includes(searchLower) ||
         booking.profiles.name.toLowerCase().includes(searchLower) ||
         booking.profiles.email.toLowerCase().includes(searchLower) ||
         booking.contact_number.includes(searchTerm))
      );
    }
    
    return matchesTab;
  });
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-amber-500 mb-4">Admin Panel</h1>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Manage all bookings for Rising Performance Hall
        </p>
      </div>
      
      <div className="mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'upcoming'
                ? 'text-amber-500 border-b-2 border-amber-500'
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('upcoming')}
          >
            Upcoming
          </button>
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'past'
                ? 'text-amber-500 border-b-2 border-amber-500'
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('past')}
          >
            Past
          </button>
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'all'
                ? 'text-amber-500 border-b-2 border-amber-500'
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('all')}
          >
            All
          </button>
        </div>
        
        {/* Search */}
        <div className="relative w-full sm:w-auto">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-500" />
          </div>
          <input
            type="text"
            className="form-input pl-10 pr-4 py-2 w-full sm:w-64"
            placeholder="Search bookings..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Bookings Table */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-900/50 border border-red-500 text-red-100 px-6 py-4 rounded-lg">
          <p>{error}</p>
        </div>
      ) : filteredBookings.length === 0 ? (
        <div className="text-center py-12 bg-gray-800 rounded-lg">
          <Filter size={48} className="mx-auto text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-300 mb-2">No bookings found</h3>
          <p className="text-gray-400">
            {searchTerm 
              ? "No bookings match your search criteria." 
              : "There are no bookings in this category."}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto bg-gray-800 rounded-lg shadow-lg">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-700">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Event
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Customer
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Date & Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {filteredBookings.map((booking) => {
                const bookingDate = parseISO(booking.booking_date);
                const formattedDate = format(bookingDate, 'MMM d, yyyy');
                const isPast = !isFuture(parseISO(`${booking.booking_date}T${booking.start_time}`));
                
                return (
                  <tr key={booking.id} className="hover:bg-gray-750">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-white">{booking.event_name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-white">{booking.profiles.name}</div>
                      <div className="text-sm text-gray-400">{booking.profiles.email}</div>
                      <div className="text-sm text-gray-400 flex items-center">
                        <Phone size={14} className="mr-1" /> {booking.contact_number}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-white">{formattedDate}</div>
                      <div className="text-sm text-gray-400">{booking.start_time} - {booking.end_time}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${booking.status === 'confirmed' 
                          ? 'bg-green-900/30 text-green-300' 
                          : 'bg-red-900/30 text-red-300'}`}
                      >
                        {booking.status === 'confirmed' ? 'Confirmed' : 'Cancelled'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <div className="flex space-x-2">
                        {booking.status === 'cancelled' ? (
                          <button
                            onClick={() => handleActionBooking(booking.id, 'confirm')}
                            disabled={processingId === booking.id || isPast}
                            className={`flex items-center p-1 rounded ${
                              isPast
                                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                                : processingId === booking.id
                                ? 'bg-amber-600 text-white'
                                : 'bg-green-600 text-white hover:bg-green-500'
                            }`}
                          >
                            {processingId === booking.id ? (
                              actionSuccess ? <Check size={16} /> : 
                              <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                            ) : (
                              <Check size={16} />
                            )}
                          </button>
                        ) : (
                          <button
                            onClick={() => handleActionBooking(booking.id, 'cancel')}
                            disabled={processingId === booking.id}
                            className={`flex items-center p-1 rounded ${
                              processingId === booking.id
                                ? 'bg-amber-600 text-white'
                                : 'bg-red-600 text-white hover:bg-red-500'
                            }`}
                          >
                            {processingId === booking.id ? (
                              actionSuccess ? <Check size={16} /> : 
                              <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                            ) : (
                              <X size={16} />
                            )}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;