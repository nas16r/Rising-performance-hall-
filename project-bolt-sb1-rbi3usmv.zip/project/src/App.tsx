import { useEffect } from 'react';
import { Route, Routes } from 'react-router-dom';

// Components
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';

// Pages
import Welcome from './pages/Welcome';
import SignUp from './pages/SignUp';
import SignIn from './pages/SignIn';
import Booking from './pages/Booking';
import MyBookings from './pages/MyBookings';
import AdminPanel from './pages/AdminPanel';
import NotFound from './pages/NotFound';

// Store and Supabase
import { useAuthStore } from './store/authStore';
import { supabase } from './lib/supabase';

function App() {
  const { setUser } = useAuthStore();

  useEffect(() => {
    // Check for existing session on load
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
          
        setUser({ 
          ...session.user,
          isAdmin: profile?.is_admin || false,
          name: profile?.name || '',
          phone: profile?.phone || ''
        });
      }
    };

    checkSession();

    // Subscribe to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
          setUser({ 
            ...session.user,
            isAdmin: profile?.is_admin || false,
            name: profile?.name || '',
            phone: profile?.phone || ''
          });
        } else {
          setUser(null);
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [setUser]);

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Welcome />} />
        <Route path="signup" element={<SignUp />} />
        <Route path="signin" element={<SignIn />} />
        
        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="booking" element={<Booking />} />
          <Route path="my-bookings" element={<MyBookings />} />
        </Route>
        
        {/* Admin Routes */}
        <Route element={<AdminRoute />}>
          <Route path="admin" element={<AdminPanel />} />
        </Route>
        
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

export default App;