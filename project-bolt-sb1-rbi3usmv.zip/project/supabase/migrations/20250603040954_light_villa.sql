/*
  # Add profile creation policy

  1. Security Changes
    - Add RLS policy to allow users to create their own profile during signup
    - Policy ensures users can only create a profile with their own auth.uid()
    - This fixes the "violates row-level security policy" error during signup

  Note: This policy complements existing policies for SELECT and UPDATE
*/

-- Add policy to allow users to create their own profile during signup
CREATE POLICY "Users can create their own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Add policy to allow public (unauthenticated) users to create their initial profile
-- This is necessary because the user isn't authenticated yet during signup
CREATE POLICY "Public can create initial profile"
  ON profiles
  FOR INSERT
  TO public
  WITH CHECK (true);